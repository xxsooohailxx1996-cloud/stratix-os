# Changelog

## 1.6.1 — Ready-to-Run Access Package

- Added one-click macOS launcher `START_STRATIX.command`.
- Added Windows launcher `START_STRATIX_WINDOWS.bat`.
- Added direct standalone file `OPEN_STRATIX_NOW.html`.
- Added Arabic first-run instructions.
- Added automatic local-network URL display for iPhone access.
- Updated PWA cache to `stratix-os-v1.6.1`.


## 1.6.0 — Institutional Chart Core

- Adopted the independent rebuild as the official STRATIX OS base.
- Rebuilt the primary chart to match the supplied institutional reference more closely.
- Added a reference-shaped market structure path with Asia, London, New York and NY Kill Zone segmentation.
- Added calculated volume profile, price ladder, POH/ONH/PDL levels, OHLC header and current-price marker.
- Added 4H Supply, 15M FVG, 1H Order Block, 5M Breaker and confirmed sell-side liquidity-hunt zones.
- Added BOS, CHoCH, Sweep and Displacement annotations.
- Added estimated actor badges, Entry, Stop, T1, T2 and live-position summary overlays.
- Added chart crosshair and OHLC/volume tooltip.
- Preserved symbol switching, timeframe switching, zoom, pan, layer toggles, RTL/LTR and workspace save.
- Data remains explicitly DEMO / ESTIMATED until a real market-data provider is connected.
- Updated PWA cache to `stratix-os-v1.6.0`.

## 1.5.0

- Initial independent STRATIX War Room rebuild.

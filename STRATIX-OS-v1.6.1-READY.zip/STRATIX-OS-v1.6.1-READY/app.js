const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const state = {
  symbol: localStorage.getItem('stratix.symbol') || 'MNQ',
  timeframe: localStorage.getItem('stratix.tf') || '15m',
  layers: { plan: true, liquidity: true, zones: true, actors: true },
  lang: localStorage.getItem('stratix.lang') || 'ar',
  zoom: 1,
  pan: 0,
  pointer: null,
};

const instruments = {
  MNQ: { base: 19580, step: 8, dec: 2, tick: 0.25 },
  NQ: { base: 19586, step: 9, dec: 2, tick: 0.25 },
  ES: { base: 6430, step: 3, dec: 2, tick: 0.25 },
  XAUUSD: { base: 2462, step: 2.1, dec: 2, tick: 0.01 },
  BTCUSD: { base: 66780, step: 95, dec: 0, tick: 1 },
};

const timeframeFactor = { '1m': 0.55, '5m': 0.78, '15m': 1, '1h': 1.55, '4h': 2.25 };

const hash = (value) => [...value].reduce((acc, char) => ((acc << 5) - acc + char.charCodeAt(0)) | 0, 1779033703) >>> 0;
function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a += 0x6D2B79F5;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function fmt(value, decimals = 2) {
  return Number(value).toLocaleString('en-US', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}
function toast(message) {
  const node = $('#toast');
  node.textContent = message;
  node.classList.add('show');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove('show'), 1800);
}
function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
function roundRect(context, x, y, width, height, radius = 3) {
  context.beginPath();
  if (typeof context.roundRect === 'function') context.roundRect(x, y, width, height, radius);
  else {
    const r = Math.min(radius, width / 2, height / 2);
    context.moveTo(x + r, y);
    context.arcTo(x + width, y, x + width, y + height, r);
    context.arcTo(x + width, y + height, x, y + height, r);
    context.arcTo(x, y + height, x, y, r);
    context.arcTo(x, y, x + width, y, r);
  }
}

const canvas = $('#chartCanvas');
const ctx = canvas.getContext('2d');
let candles = [];
let chartModel = null;

function structureDrift(index, total, step) {
  const n = index / Math.max(1, total - 1);
  if (n < 0.19) return step * 0.33;
  if (n < 0.31) return step * 0.14;
  if (n < 0.41) return step * 0.41;
  if (n < 0.50) return step * -0.27;
  if (n < 0.59) return step * 0.48;
  if (n < 0.67) return step * 0.94;
  if (n < 0.75) return step * -1.07;
  if (n < 0.83) return step * 0.22;
  return step * -0.31;
}

function makeData() {
  const config = instruments[state.symbol];
  const factor = timeframeFactor[state.timeframe] || 1;
  const random = rng(hash(`${state.symbol}:${state.timeframe}:v160`));
  const count = 92;
  let price = config.base - config.step * 17 * factor;

  candles = Array.from({ length: count }, (_, index) => {
    const drift = structureDrift(index, count, config.step * factor);
    const microWave = Math.sin(index * 0.73) * config.step * 0.18 * factor;
    const noise = (random() - 0.5) * config.step * 0.9 * factor;
    const open = price;
    let close = open + drift + microWave + noise;

    if (index === 53) close += config.step * 1.6 * factor;
    if (index === 54) close += config.step * 1.2 * factor;
    if (index === 61) close -= config.step * 1.5 * factor;
    if (index === 62) close -= config.step * 1.1 * factor;

    const wickUp = config.step * factor * (0.34 + random() * 0.76);
    const wickDown = config.step * factor * (0.30 + random() * 0.72);
    const high = Math.max(open, close) + wickUp;
    const low = Math.min(open, close) - wickDown;
    const volume = 38 + random() * 86 + Math.abs(close - open) / Math.max(config.step * factor, 0.0001) * 32;
    price = close;
    return { o: open, h: high, l: low, c: close, v: volume };
  });

  state.pan = clamp(state.pan, 0, Math.max(0, candles.length - 24));
  drawChart();
  updateDashboard();
}

function resizeCanvas() {
  const rect = canvas.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.max(1, Math.floor(rect.width * dpr));
  canvas.height = Math.max(1, Math.floor(rect.height * dpr));
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  drawChart();
}

function canvasText(text, x, y, color, font = '9px ui-monospace, monospace', align = 'left') {
  ctx.fillStyle = color;
  ctx.font = font;
  ctx.textAlign = align;
  ctx.textBaseline = 'alphabetic';
  ctx.fillText(text, x, y);
}

function pill(x, y, text, color, background = 'rgba(4,16,27,.94)', align = 'left') {
  ctx.font = '9px ui-monospace, monospace';
  const width = ctx.measureText(text).width + 12;
  const left = align === 'right' ? x - width : x;
  ctx.fillStyle = background;
  roundRect(ctx, left, y - 13, width, 18, 3);
  ctx.fill();
  ctx.strokeStyle = color;
  ctx.lineWidth = 0.7;
  ctx.stroke();
  canvasText(text, align === 'right' ? x - 6 : x + 6, y, color, '9px ui-monospace, monospace', align);
  return { left, width };
}

function drawDiamond(x, y, color, size = 5) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(Math.PI / 4);
  ctx.fillStyle = 'rgba(4,16,27,.9)';
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  ctx.fillRect(-size / 2, -size / 2, size, size);
  ctx.strokeRect(-size / 2, -size / 2, size, size);
  ctx.restore();
}

function drawActorBadge(x, y, glyph, color) {
  ctx.save();
  ctx.shadowColor = color;
  ctx.shadowBlur = 7;
  ctx.fillStyle = 'rgba(4,15,24,.92)';
  ctx.strokeStyle = color;
  roundRect(ctx, x - 7, y - 7, 14, 14, 3);
  ctx.fill();
  ctx.stroke();
  ctx.shadowBlur = 0;
  canvasText(glyph, x, y + 4, color, '10px serif', 'center');
  ctx.restore();
}

function buildProfile(data, bins = 36) {
  const high = Math.max(...data.map((item) => item.h));
  const low = Math.min(...data.map((item) => item.l));
  const span = Math.max(high - low, 0.000001);
  const profile = Array.from({ length: bins }, () => 0);
  data.forEach((item) => {
    const center = (item.h + item.l + item.c) / 3;
    const index = clamp(Math.floor(((center - low) / span) * bins), 0, bins - 1);
    profile[index] += item.v;
    if (index > 0) profile[index - 1] += item.v * 0.35;
    if (index < bins - 1) profile[index + 1] += item.v * 0.35;
  });
  return { high, low, values: profile, max: Math.max(...profile) || 1 };
}

function chartLevels(data, config) {
  const max = Math.max(...data.map((item) => item.h));
  const min = Math.min(...data.map((item) => item.l));
  const range = Math.max(max - min, config.step * 8);
  const last = data[data.length - 1].c;
  const entry = last + config.step * 0.18;
  return {
    supplyHigh: min + range * 0.84,
    supplyLow: min + range * 0.75,
    fvgHigh: min + range * 0.66,
    fvgLow: min + range * 0.58,
    orderHigh: min + range * 0.36,
    orderLow: min + range * 0.28,
    breakerHigh: min + range * 0.24,
    breakerLow: min + range * 0.19,
    huntHigh: min + range * 0.14,
    huntLow: min + range * 0.10,
    entry,
    stop: entry - config.step * 5.2,
    t1: entry + config.step * 5.8,
    t2: entry + config.step * 8.5,
    poh: max + config.step * 4.7,
    onh: max + config.step * 0.9,
    pdl: min - config.step * 2.2,
  };
}

function drawChart() {
  if (!ctx || !canvas.clientWidth || !candles.length) return;

  const width = canvas.clientWidth;
  const height = canvas.clientHeight;
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = '#03101a';
  ctx.fillRect(0, 0, width, height);

  const config = instruments[state.symbol];
  const left = Math.max(54, Math.min(76, width * 0.09));
  const right = Math.max(78, Math.min(104, width * 0.125));
  const top = 34;
  const bottom = 34;
  const plotWidth = Math.max(100, width - left - right);
  const plotHeight = Math.max(100, height - top - bottom);
  const visible = clamp(Math.floor(82 / state.zoom), 38, candles.length);
  const maxStart = Math.max(0, candles.length - visible);
  const start = clamp(Math.floor(state.pan), 0, maxStart);
  const data = candles.slice(start, start + visible);

  const rawHigh = Math.max(...data.map((item) => item.h));
  const rawLow = Math.min(...data.map((item) => item.l));
  const modelLevels = chartLevels(data, config);
  const high = Math.max(rawHigh, modelLevels.poh) + config.step * 0.8;
  const low = Math.min(rawLow, modelLevels.pdl) - config.step * 0.8;
  const span = Math.max(high - low, config.step * 10);
  const toY = (value) => top + ((high - value) / span) * plotHeight;
  const toX = (index) => left + ((index + 0.5) / data.length) * plotWidth;
  const candleWidth = clamp((plotWidth / data.length) * 0.6, 2.5, 9);

  chartModel = { width, height, left, right, top, bottom, plotWidth, plotHeight, data, start, high, low, span, toY, toX, levels: modelLevels };

  const sessions = [
    { label: 'ASIA', from: 0, to: 0.31, fill: 'rgba(108,62,164,.055)', color: '#a26fe5' },
    { label: 'LONDON', from: 0.31, to: 0.58, fill: 'rgba(255,141,56,.045)', color: '#ff8d38' },
    { label: 'NEW YORK', from: 0.58, to: 1, fill: 'rgba(22,120,232,.055)', color: '#219bf0' },
  ];
  sessions.forEach((session) => {
    const x1 = left + plotWidth * session.from;
    const x2 = left + plotWidth * session.to;
    ctx.fillStyle = session.fill;
    ctx.fillRect(x1, top, x2 - x1, plotHeight);
    ctx.strokeStyle = 'rgba(19,51,70,.75)';
    ctx.beginPath();
    ctx.moveTo(x1, top);
    ctx.lineTo(x1, top + plotHeight);
    ctx.stroke();
    canvasText(session.label, x1 + 8, top + 14, session.color, '10px ui-monospace, monospace');
  });
  canvasText('NY KILL ZONE • 9:30–11:30 AM ET', left + plotWidth * 0.71, top + 14, '#2588cb', '9px ui-monospace, monospace');

  ctx.lineWidth = 0.7;
  ctx.strokeStyle = '#0b2b3c';
  for (let row = 0; row <= 8; row += 1) {
    const y = top + (plotHeight * row) / 8;
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(left + plotWidth, y);
    ctx.stroke();
    const value = high - (span * row) / 8;
    canvasText(fmt(value, config.dec), width - 7, y + 3, '#7892a6', '8px ui-monospace, monospace', 'right');
  }
  for (let column = 0; column <= 6; column += 1) {
    const x = left + (plotWidth * column) / 6;
    ctx.beginPath();
    ctx.moveTo(x, top);
    ctx.lineTo(x, top + plotHeight);
    ctx.stroke();
    const hour = (6 + column * 3) % 24;
    canvasText(`${String(hour).padStart(2, '0')}:00`, x, height - 10, '#718a9c', '8px ui-monospace, monospace', 'center');
  }

  if (state.layers.liquidity) {
    const profile = buildProfile(data, 39);
    const barHeight = plotHeight / profile.values.length;
    profile.values.forEach((volume, index) => {
      const y = top + plotHeight - (index + 1) * barHeight;
      const normalized = volume / profile.max;
      const barWidth = Math.max(4, normalized * (left - 10));
      ctx.fillStyle = normalized > 0.78 ? 'rgba(130,166,185,.62)' : 'rgba(119,151,169,.38)';
      ctx.fillRect(left - barWidth, y + 1, barWidth, Math.max(2, barHeight - 2));
    });
    ctx.strokeStyle = 'rgba(142,178,197,.25)';
    ctx.beginPath();
    ctx.moveTo(left, top);
    ctx.lineTo(left, top + plotHeight);
    ctx.stroke();
  }

  const drawZone = (x1Ratio, x2Ratio, upper, lower, color, fill, title, subtitle) => {
    const x1 = left + plotWidth * x1Ratio;
    const x2 = left + plotWidth * x2Ratio;
    const y1 = toY(upper);
    const y2 = toY(lower);
    ctx.fillStyle = fill;
    ctx.fillRect(x1, y1, x2 - x1, y2 - y1);
    ctx.strokeStyle = color;
    ctx.lineWidth = 0.8;
    ctx.strokeRect(x1, y1, x2 - x1, y2 - y1);
    canvasText(title, x1 + 7, y1 + 13, color, '9px ui-monospace, monospace');
    canvasText(subtitle, x1 + 7, y1 + 26, '#899faf', '8px ui-monospace, monospace');
  };

  if (state.layers.zones) {
    drawZone(0.53, 0.88, modelLevels.supplyHigh, modelLevels.supplyLow, '#ff5c70', 'rgba(255,77,102,.05)', '4H SUPPLY • Fresh', 'ORIGIN • 4H');
    drawZone(0.57, 0.83, modelLevels.fvgHigh, modelLevels.fvgLow, '#2487c7', 'rgba(36,174,243,.055)', '15M FVG', 'ORIGIN • 15M');
    drawZone(0.27, 0.58, modelLevels.orderHigh, modelLevels.orderLow, '#165381', 'rgba(22,120,232,.045)', '1H ORDER BLOCK', 'ORIGIN • 1H');
    drawZone(0.27, 0.58, modelLevels.breakerHigh, modelLevels.breakerLow, '#a96d2e', 'rgba(255,141,56,.04)', '5M BREAKER • Fresh', 'ORIGIN • 5M');
    drawZone(0.27, 0.74, modelLevels.huntHigh, modelLevels.huntLow, '#287e58', 'rgba(36,206,136,.035)', 'SELL-SIDE LIQUIDITY HUNT • CONFIRMED', `ORIGIN • ${state.timeframe.toUpperCase()}`);
  }

  const maxVolume = Math.max(...data.map((item) => item.v));
  data.forEach((candle, index) => {
    const x = toX(index);
    const rising = candle.c >= candle.o;
    const wickColor = rising ? '#188fff' : '#d6e5ec';
    const bodyColor = rising ? '#167fe8' : '#cbd9e0';
    ctx.strokeStyle = wickColor;
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, toY(candle.h));
    ctx.lineTo(x, toY(candle.l));
    ctx.stroke();
    const bodyTop = Math.min(toY(candle.o), toY(candle.c));
    const bodyHeight = Math.max(1.2, Math.abs(toY(candle.o) - toY(candle.c)));
    ctx.fillStyle = bodyColor;
    ctx.fillRect(x - candleWidth / 2, bodyTop, candleWidth, bodyHeight);
    if (candle.v > maxVolume * 0.86) {
      ctx.fillStyle = rising ? 'rgba(36,174,243,.18)' : 'rgba(255,77,102,.15)';
      ctx.fillRect(x - candleWidth, top + plotHeight - 5, candleWidth * 2, 5);
    }
  });

  if (state.layers.plan) {
    const markerSpecs = [
      { index: 13, label: 'BOS', color: '#27d089', dy: -25 },
      { index: 29, label: 'CHoCH', color: '#27d089', dy: 30 },
      { index: 49, label: 'SWEEP', color: '#9483dc', dy: -28 },
      { index: 61, label: 'DISPLACEMENT', color: '#2489eb', dy: 32 },
    ];
    markerSpecs.forEach((marker) => {
      if (marker.index < start || marker.index >= start + data.length) return;
      const local = marker.index - start;
      const x = toX(local);
      const baseY = toY(candles[marker.index].c);
      const targetY = baseY + marker.dy;
      ctx.strokeStyle = marker.color;
      ctx.setLineDash([3, 3]);
      ctx.beginPath();
      ctx.moveTo(x, baseY);
      ctx.lineTo(x, targetY);
      ctx.stroke();
      ctx.setLineDash([]);
      canvasText(marker.label, x, targetY + (marker.dy < 0 ? -4 : 12), marker.color, '8px ui-monospace, monospace', 'center');
    });

    const tradeLines = [
      { name: 'T2', value: modelLevels.t2, color: '#24ce88' },
      { name: 'T1', value: modelLevels.t1, color: '#24ce88' },
      { name: 'ENTRY', value: modelLevels.entry, color: '#24aef3' },
      { name: 'SL', value: modelLevels.stop, color: '#ff4d66' },
    ];
    tradeLines.forEach((line) => {
      const y = toY(line.value);
      ctx.strokeStyle = line.color;
      ctx.lineWidth = 0.9;
      ctx.setLineDash([5, 4]);
      ctx.beginPath();
      ctx.moveTo(left + plotWidth * 0.61, y);
      ctx.lineTo(left + plotWidth, y);
      ctx.stroke();
      ctx.setLineDash([]);
      pill(left + plotWidth - 3, y, `${line.name}  ${fmt(line.value, config.dec)}`, line.color, 'rgba(4,15,24,.94)', 'right');
    });

    const liveY = toY(modelLevels.entry - config.step * 1.1);
    const liveX = left + plotWidth * 0.67;
    const liveWidth = plotWidth * 0.33 - 6;
    ctx.fillStyle = 'rgba(36,206,136,.045)';
    ctx.strokeStyle = 'rgba(36,206,136,.35)';
    roundRect(ctx, liveX, liveY - 14, liveWidth, 24, 3);
    ctx.fill();
    ctx.stroke();
    canvasText('LIVE • +5.36 • 1.28 RR', liveX + 8, liveY + 2, '#24ce88', '9px ui-monospace, monospace');
  }

  if (state.layers.actors) {
    const actorMarkers = [
      { index: 4, glyph: '◇', color: '#a681cc' },
      { index: 17, glyph: '♜', color: '#d39bfa' },
      { index: 24, glyph: '▰', color: '#f2c844' },
      { index: 34, glyph: '⌁', color: '#10d8c4' },
      { index: 44, glyph: '♜', color: '#d39bfa' },
      { index: 56, glyph: '▰', color: '#f2c844' },
      { index: 63, glyph: '◇', color: '#e86d4a' },
    ];
    actorMarkers.forEach((actor, actorIndex) => {
      if (actor.index < start || actor.index >= start + data.length) return;
      const local = actor.index - start;
      const candle = candles[actor.index];
      const y = actorIndex % 2 ? toY(candle.h) - 13 : toY(candle.l) + 15;
      drawActorBadge(toX(local), y, actor.glyph, actor.color);
    });
  }

  const last = data[data.length - 1].c;
  const lastY = toY(last);
  ctx.fillStyle = '#1678e8';
  ctx.fillRect(width - right, lastY - 9, right, 18);
  canvasText(fmt(last, config.dec), width - right / 2, lastY + 3, '#ffffff', '10px ui-monospace, monospace', 'center');

  const ladder = [
    { label: 'POH', value: modelLevels.poh, color: '#7d94a5' },
    { label: 'ONH', value: modelLevels.onh, color: '#7d94a5' },
    { label: 'PDL', value: modelLevels.pdl, color: '#a689d7' },
  ];
  ladder.forEach((level) => {
    const y = toY(level.value);
    const boxX = width - right + 6;
    ctx.fillStyle = 'rgba(8,27,42,.95)';
    ctx.strokeStyle = '#17364b';
    roundRect(ctx, boxX, y - 13, right - 12, 25, 3);
    ctx.fill();
    ctx.stroke();
    canvasText(level.label, boxX + 7, y - 1, level.color, '8px ui-monospace, monospace');
    canvasText(fmt(level.value, config.dec), width - 7, y + 8, '#9cb2c0', '8px ui-monospace, monospace', 'right');
  });

  const first = data[0];
  const current = data[data.length - 1];
  const change = current.c - first.o;
  const changeColor = change >= 0 ? '#24ce88' : '#ff4d66';
  canvasText(`${state.symbol} • ${state.timeframe.toUpperCase()}`, left + 5, 20, '#b5c8d3', '9px ui-monospace, monospace');
  canvasText(`O ${fmt(current.o, config.dec)}  H ${fmt(current.h, config.dec)}  L ${fmt(current.l, config.dec)}  C ${fmt(current.c, config.dec)}`, left + 92, 20, '#708b9e', '8px ui-monospace, monospace');
  canvasText(`${change >= 0 ? '+' : ''}${fmt(change, config.dec)}`, width - right - 8, 20, changeColor, '9px ui-monospace, monospace', 'right');

  if (state.pointer && state.pointer.x >= left && state.pointer.x <= left + plotWidth && state.pointer.y >= top && state.pointer.y <= top + plotHeight) {
    const index = clamp(Math.floor(((state.pointer.x - left) / plotWidth) * data.length), 0, data.length - 1);
    const candle = data[index];
    const x = toX(index);
    const value = high - ((state.pointer.y - top) / plotHeight) * span;
    ctx.strokeStyle = 'rgba(143,171,188,.45)';
    ctx.lineWidth = 0.7;
    ctx.setLineDash([3, 3]);
    ctx.beginPath();
    ctx.moveTo(x, top);
    ctx.lineTo(x, top + plotHeight);
    ctx.moveTo(left, state.pointer.y);
    ctx.lineTo(left + plotWidth, state.pointer.y);
    ctx.stroke();
    ctx.setLineDash([]);
    pill(left + plotWidth - 2, state.pointer.y, fmt(value, config.dec), '#98b1c0', 'rgba(4,15,24,.96)', 'right');
    const tooltipX = clamp(x + 10, left + 6, left + plotWidth - 155);
    const tooltipY = clamp(state.pointer.y - 70, top + 6, top + plotHeight - 65);
    ctx.fillStyle = 'rgba(4,15,24,.96)';
    ctx.strokeStyle = '#1a455f';
    roundRect(ctx, tooltipX, tooltipY, 148, 58, 3);
    ctx.fill();
    ctx.stroke();
    canvasText(`O ${fmt(candle.o, config.dec)}  H ${fmt(candle.h, config.dec)}`, tooltipX + 8, tooltipY + 17, '#9eb3c0', '8px ui-monospace, monospace');
    canvasText(`L ${fmt(candle.l, config.dec)}  C ${fmt(candle.c, config.dec)}`, tooltipX + 8, tooltipY + 32, '#9eb3c0', '8px ui-monospace, monospace');
    canvasText(`VOL ${fmt(candle.v, 0)} • DEMO`, tooltipX + 8, tooltipY + 47, '#24aef3', '8px ui-monospace, monospace');
  }
}

function drawLiquidity() {
  const target = $('#liquidityCanvas');
  const context = target.getContext('2d');
  const rect = target.getBoundingClientRect();
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  target.width = Math.max(1, Math.floor(rect.width * dpr));
  target.height = Math.max(1, Math.floor(rect.height * dpr));
  context.setTransform(dpr, 0, 0, dpr, 0, 0);
  context.clearRect(0, 0, rect.width, rect.height);
  const random = rng(hash(`${state.symbol}:liquidity:v160`));
  for (let index = 0; index < 52; index += 1) {
    const value = 8 + random() * 34 + Math.sin(index * 0.48) * 7;
    context.fillStyle = index % 4 === 0 ? '#24ce88' : '#24aef3';
    context.fillRect(index * rect.width / 52, rect.height - value, Math.max(2, rect.width / 76), value);
  }
}

function renderOrders(last, random) {
  const actors = ['Institution', 'Fund', 'Whale', 'Institution', 'Unknown', 'Large Portfolio', 'Whale'];
  const types = ['LIMIT WALL', 'ICEBERG', 'ABSORPTION', 'RESTING', 'STOP FLOW (EST)', 'EXECUTED', 'RESTING'];
  const locations = ['1H', 'Within 15M FVG', 'Above Breaker', 'Entry', 'S AREA', 'Inside 1H FVG', 'Below 1H FVG'];
  const config = instruments[state.symbol];
  $('#ordersBody').innerHTML = actors.map((actor, index) => {
    const side = index < 3 || index === 6 ? 'BUY' : 'SELL';
    const confidence = 61 + Math.floor(random() * 26);
    const price = last + config.step * (3 - index * 1.35);
    const size = 18 + Math.floor(random() * 42);
    return `<tr><td>${index + 1}</td><td>${fmt(price, config.dec)}</td><td>${size}K</td><td class="${side === 'BUY' ? 'green' : 'red'}">${side}</td><td>${actor}</td><td>${types[index]}</td><td>${locations[index]}</td><td><span class="confidence">${confidence}%<i style="--w:${confidence}%"></i></span></td></tr>`;
  }).join('');
}

function updateDashboard() {
  const config = instruments[state.symbol];
  const random = rng(hash(`${state.symbol}:${state.timeframe}:dashboard`));
  const last = candles.at(-1)?.c || config.base;
  $('#chartSymbol').textContent = state.symbol;
  $('#symbolSelect').value = state.symbol;
  $('#timeframeSelect').value = state.timeframe;
  $('#scoreValue').textContent = 83 + Math.floor(random() * 4);
  $('#instVol').textContent = `${(48 + random() * 17).toFixed(1)}K`;
  $('#fundVol').textContent = `${(36 + random() * 14).toFixed(1)}K`;
  $('#whaleVol').textContent = `${(31 + random() * 13).toFixed(1)}K`;
  $('#portfolioVol').textContent = `${(20 + random() * 10).toFixed(1)}K`;
  $('#unknownVol').textContent = `${(22 + random() * 11).toFixed(1)}K`;
  $('#orderRange').textContent = `${fmt(last - config.step * 6, config.dec)}–${fmt(last - config.step * 4.3, config.dec)}`;
  renderOrders(last, random);
  drawLiquidity();
}

const eventTarget = new Date(Date.now() + ((102 * 60 + 18) * 1000));
function updateClocks() {
  const now = new Date();
  const time = (timeZone) => new Intl.DateTimeFormat('en-US', { timeZone, hour: 'numeric', minute: '2-digit', second: '2-digit' }).format(now);
  $('#ksaTime').textContent = time('Asia/Riyadh');
  $('#etTime').textContent = time('America/New_York');
  const etParts = new Intl.DateTimeFormat('en-GB', { timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(now);
  const hour = Number(etParts.find((part) => part.type === 'hour').value);
  const minute = Number(etParts.find((part) => part.type === 'minute').value);
  const minutes = hour * 60 + minute;
  const open = 9 * 60 + 30;
  const close = 11 * 60 + 30;
  const diff = minutes < open ? open - minutes : minutes < close ? close - minutes : 24 * 60 - minutes + open;
  $('#sessionCountdown').textContent = `${String(Math.floor(diff / 60)).padStart(2, '0')}:${String(diff % 60).padStart(2, '0')}:00 LEFT`;
  $('#activeSession').textContent = minutes >= open && minutes < close ? 'NY SESSION' : 'NEXT NY SESSION';
  $('#nyState').textContent = minutes >= open && minutes < close ? 'OPEN • NY KILL ZONE' : 'NY CASH 4:30 PM KSA';
  $('#asiaState').textContent = 'CLOSED';
  $('#londonState').textContent = 'CLOSED';
  const seconds = Math.max(0, Math.floor((eventTarget - now) / 1000));
  $('#eventCountdown').textContent = `${String(Math.floor(seconds / 3600)).padStart(2, '0')}:${String(Math.floor((seconds % 3600) / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}

$('#symbolSelect').addEventListener('change', (event) => {
  state.symbol = event.target.value;
  localStorage.setItem('stratix.symbol', state.symbol);
  state.pan = 0;
  makeData();
  toast(`Symbol: ${state.symbol}`);
});

$('#timeframeSelect').addEventListener('change', (event) => {
  state.timeframe = event.target.value;
  localStorage.setItem('stratix.tf', state.timeframe);
  state.pan = 0;
  makeData();
  toast(`Timeframe: ${state.timeframe}`);
});

$$('.layer-tab').forEach((button) => button.addEventListener('click', () => {
  const key = button.dataset.layer;
  state.layers[key] = !state.layers[key];
  button.classList.toggle('active', state.layers[key]);
  drawChart();
}));

$('#resetChart').addEventListener('click', () => {
  state.zoom = 1;
  state.pan = 0;
  state.pointer = null;
  drawChart();
  toast('Chart reset');
});

$('#langBtn').addEventListener('click', () => {
  state.lang = state.lang === 'ar' ? 'en' : 'ar';
  document.documentElement.dir = state.lang === 'ar' ? 'rtl' : 'ltr';
  document.documentElement.lang = state.lang;
  localStorage.setItem('stratix.lang', state.lang);
  toast(state.lang === 'ar' ? 'تم تفعيل العربية' : 'English enabled');
});

$('#saveBtn').addEventListener('click', () => {
  localStorage.setItem('stratix.workspace', JSON.stringify(state));
  toast('Workspace saved');
});

$('#fullscreenBtn').addEventListener('click', async () => {
  try {
    if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
    else await document.exitFullscreen();
  } catch {
    toast('Fullscreen unavailable');
  }
});

canvas.addEventListener('wheel', (event) => {
  event.preventDefault();
  state.zoom = clamp(state.zoom + (event.deltaY < 0 ? 0.1 : -0.1), 0.85, 2.2);
  drawChart();
}, { passive: false });

let dragging = false;
let lastX = 0;
canvas.addEventListener('pointerdown', (event) => {
  dragging = true;
  lastX = event.clientX;
  canvas.setPointerCapture(event.pointerId);
});
canvas.addEventListener('pointermove', (event) => {
  const rect = canvas.getBoundingClientRect();
  state.pointer = { x: event.clientX - rect.left, y: event.clientY - rect.top };
  if (dragging) {
    const delta = event.clientX - lastX;
    lastX = event.clientX;
    state.pan = clamp(state.pan - delta / 11, 0, Math.max(0, candles.length - 24));
  }
  drawChart();
});
canvas.addEventListener('pointerleave', () => {
  if (!dragging) {
    state.pointer = null;
    drawChart();
  }
});
canvas.addEventListener('pointerup', () => {
  dragging = false;
});
canvas.addEventListener('pointercancel', () => {
  dragging = false;
});

window.addEventListener('resize', resizeCanvas);
new ResizeObserver(resizeCanvas).observe(canvas.parentElement);
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});

const saved = localStorage.getItem('stratix.workspace');
if (saved) {
  try {
    Object.assign(state, JSON.parse(saved));
  } catch {
    localStorage.removeItem('stratix.workspace');
  }
}

document.documentElement.dir = state.lang === 'ar' ? 'rtl' : 'ltr';
document.documentElement.lang = state.lang;
makeData();
resizeCanvas();
updateClocks();
setInterval(updateClocks, 1000);

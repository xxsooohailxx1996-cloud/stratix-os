# STRATIX OS Master Rebuild v1.6.0 — Test Report

Date: 2026-08-01

## Scope

This release adopts the independent rebuild as the official STRATIX OS base and upgrades the main chart to the supplied institutional reference layout.

## Static and syntax checks

- `node --check app.js`: PASS
- `node --check sw.js`: PASS
- Required project files: PASS
- Manifest JSON and standalone display: PASS

## Browser/CDP smoke test

Reference viewport: 708 × 1536

- Required UI sections: PASS
- Horizontal overflow: NONE
- Canvas chart render: PASS
- Symbol switch MNQ → BTCUSD: PASS
- Symbol switch changes chart pixels: PASS
- Timeframe switch 15m → 1h: PASS
- Layer toggle: PASS
- RTL/LTR toggle: PASS
- Workspace save: PASS
- CSS rules loaded: PASS
- Runtime errors: 0

## Mobile smoke tests

### iPhone portrait — 430 × 932

- Horizontal overflow: NONE
- Canvas correctly sized: PASS
- Chart pixels rendered: PASS
- Runtime errors: 0

### iPhone landscape — 932 × 430

- Horizontal overflow: NONE
- Canvas correctly sized: PASS
- Chart pixels rendered: PASS
- Runtime errors: 0

## Rendered screenshots

- `screenshots/reference-708-full-v1.6.0.png`
- `screenshots/desktop-1440-v1.6.0.png`
- `screenshots/tablet-landscape-v1.6.0.png`
- `screenshots/iphone-landscape-v1.6.0.png`
- `screenshots/iphone-portrait-v1.6.0.png`

## Chart features verified

- Candlestick rendering
- Asia, London, New York and NY Kill Zone segmentation
- Volume/liquidity profile
- Price ladder with POH, ONH and PDL
- 4H Supply, 15M FVG, 1H Order Block and 5M Breaker zones
- BOS, CHoCH, Sweep and Displacement labels
- Entry, Stop, T1, T2 and position summary
- Estimated actor markers
- Crosshair and OHLC/volume tooltip
- Zoom, pan, reset and layer controls

## Data status

- Market feed: DEMO
- Actor classification: ESTIMATED
- Order flow: ESTIMATED
- Broker execution: NOT CONNECTED
- Live futures feed: NOT CONNECTED

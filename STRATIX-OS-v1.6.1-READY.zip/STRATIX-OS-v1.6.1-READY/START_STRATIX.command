#!/bin/bash
set -e
cd "$(dirname "$0")"

PORT=8080
while lsof -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1; do
  PORT=$((PORT+1))
done

IP="$(ipconfig getifaddr en0 2>/dev/null || true)"
if [ -z "$IP" ]; then IP="$(ipconfig getifaddr en1 2>/dev/null || true)"; fi

clear
echo "==============================================="
echo " STRATIX OS v1.6.1 — LOCAL SERVER"
echo "==============================================="
echo ""
echo "Mac:    http://localhost:$PORT"
if [ -n "$IP" ]; then
  echo "iPhone: http://$IP:$PORT"
  echo "(Mac and iPhone must be on the same Wi-Fi)"
fi
echo ""
echo "Leave this Terminal window open while using STRATIX."
echo "Press Control+C here to stop the system."
echo ""

open "http://localhost:$PORT"
python3 -m http.server "$PORT" --bind 0.0.0.0

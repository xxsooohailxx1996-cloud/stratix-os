import json, time, sys, requests, websocket
from pathlib import Path

root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text();css=(root/'style.css').read_text();js=(root/'app.js').read_text()
pre="window.__stratixStorage={_:{},getItem(k){return this._[k]??null},setItem(k,v){this._[k]=String(v)},removeItem(k){delete this._[k]}};window.__errors=[];window.addEventListener('error',e=>window.__errors.push(String(e.message||e.error)));window.addEventListener('unhandledrejection',e=>window.__errors.push(String(e.reason)));"
js=pre+js.replace('localStorage','window.__stratixStorage').replace("if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});",'')
html=html.replace('<link rel="manifest" href="manifest.webmanifest" />','').replace('<link rel="apple-touch-icon" href="assets/icon-192.png" />','').replace('<link rel="stylesheet" href="style.css" />',f'<style>{css}</style>').replace('<script type="module" src="app.js"></script>',f'<script>{js}</script>')
port=int(sys.argv[1] if len(sys.argv)>1 else 9250)
tabs=requests.get(f'http://127.0.0.1:{port}/json',timeout=2).json();base=websocket.create_connection(tabs[0]['webSocketDebuggerUrl'],timeout=10,origin=f'http://127.0.0.1:{port}')
seq=0
def bc(method,params=None):
 global seq;seq+=1;base.send(json.dumps({'id':seq,'method':method,'params':params or {}}))
 while True:
  msg=json.loads(base.recv())
  if msg.get('id')==seq:return msg.get('result',{})

def run_viewport(width,height):
 target=bc('Target.createTarget',{'url':'about:blank'})['targetId'];time.sleep(.1)
 tab=next(t for t in requests.get(f'http://127.0.0.1:{port}/json',timeout=2).json() if t.get('id')==target)
 ws=websocket.create_connection(tab['webSocketDebuggerUrl'],timeout=10,origin=f'http://127.0.0.1:{port}');i=0
 def call(method,params=None):
  nonlocal i;i+=1;ws.send(json.dumps({'id':i,'method':method,'params':params or {}}))
  while True:
   msg=json.loads(ws.recv())
   if msg.get('id')==i:return msg.get('result',{})
 def ev(expr):return call('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})['result'].get('value')
 call('Page.enable');call('Runtime.enable');call('Emulation.setDeviceMetricsOverride',{'width':width,'height':height,'deviceScaleFactor':2,'mobile':True,'screenWidth':width,'screenHeight':height})
 frame=call('Page.getFrameTree')['frameTree']['frame']['id'];call('Page.setDocumentContent',{'frameId':frame,'html':html});time.sleep(1.5);ev('resizeCanvas();drawChart();')
 result={
  'viewport':f'{width}x{height}',
  'no_horizontal_overflow':ev('document.documentElement.scrollWidth<=window.innerWidth+1'),
  'canvas_sized':ev("(()=>{const c=document.querySelector('#chartCanvas');return c.width>600&&c.height>400})()"),
  'canvas_nonempty':ev("document.querySelector('#chartCanvas').toDataURL().length>10000"),
  'runtime_errors':ev('window.__errors')
 }
 ws.close();bc('Target.closeTarget',{'targetId':target});return result

results=[run_viewport(430,932),run_viewport(932,430)]
print(json.dumps(results,indent=2,ensure_ascii=False))
failed=[]
for r in results:
 if not r['no_horizontal_overflow'] or not r['canvas_sized'] or not r['canvas_nonempty'] or r['runtime_errors']:failed.append(r['viewport'])
if failed:raise SystemExit('Mobile smoke failed: '+', '.join(failed))
print('Mobile smoke tests passed')

import json, time, sys, requests, websocket
from pathlib import Path

root=Path(__file__).resolve().parents[1]
html=(root/'index.html').read_text();css=(root/'style.css').read_text();js=(root/'app.js').read_text()
pre="window.__stratixStorage={_:{},getItem(k){return this._[k]??null},setItem(k,v){this._[k]=String(v)},removeItem(k){delete this._[k]}};window.__errors=[];window.addEventListener('error',e=>window.__errors.push(String(e.message||e.error)));window.addEventListener('unhandledrejection',e=>window.__errors.push(String(e.reason)));"
js=pre+js.replace('localStorage','window.__stratixStorage').replace("if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});",'')
html=html.replace('<link rel="manifest" href="manifest.webmanifest" />','').replace('<link rel="apple-touch-icon" href="assets/icon-192.png" />','').replace('<link rel="stylesheet" href="style.css" />',f'<style>{css}</style>').replace('<script type="module" src="app.js"></script>',f'<script>{js}</script>')
port=int(sys.argv[1] if len(sys.argv)>1 else 9250)
tabs=requests.get(f'http://127.0.0.1:{port}/json',timeout=2).json();base=websocket.create_connection(tabs[0]['webSocketDebuggerUrl'],timeout=10,origin=f'http://127.0.0.1:{port}')
seq=0
def base_call(method,params=None):
 global seq;seq+=1;base.send(json.dumps({'id':seq,'method':method,'params':params or {}}))
 while True:
  msg=json.loads(base.recv())
  if msg.get('id')==seq:return msg.get('result',{})

target=base_call('Target.createTarget',{'url':'about:blank'})['targetId'];time.sleep(.1)
tab=next(t for t in requests.get(f'http://127.0.0.1:{port}/json',timeout=2).json() if t.get('id')==target)
ws=websocket.create_connection(tab['webSocketDebuggerUrl'],timeout=10,origin=f'http://127.0.0.1:{port}');i=0
def call(method,params=None):
 global i;i+=1;ws.send(json.dumps({'id':i,'method':method,'params':params or {}}))
 while True:
  msg=json.loads(ws.recv())
  if msg.get('id')==i:
   if 'error' in msg:raise RuntimeError(msg['error'])
   return msg.get('result',{})
def ev(expr):return call('Runtime.evaluate',{'expression':expr,'returnByValue':True,'awaitPromise':True})['result'].get('value')

call('Page.enable');call('Runtime.enable')
call('Emulation.setDeviceMetricsOverride',{'width':708,'height':1536,'deviceScaleFactor':1,'mobile':False,'screenWidth':708,'screenHeight':1536})
frame=call('Page.getFrameTree')['frameTree']['frame']['id'];call('Page.setDocumentContent',{'frameId':frame,'html':html});time.sleep(1.5);ev('resizeCanvas();drawChart();')
results={}
results['required_sections']=ev("['chartCanvas','ordersBody','liquidityCanvas','scoreValue','harmonyRing'].every(id=>!!document.getElementById(id))")
results['no_horizontal_overflow']=ev('document.documentElement.scrollWidth <= window.innerWidth + 1')
initial=ev("document.querySelector('#chartCanvas').toDataURL()")
results['initial_canvas_nonempty']=len(initial)>10000
results['symbol_switch']=ev("(()=>{const e=document.querySelector('#symbolSelect');e.value='BTCUSD';e.dispatchEvent(new Event('change',{bubbles:true}));return document.querySelector('#chartSymbol').textContent==='BTCUSD'})()")
time.sleep(.15);after_symbol=ev("document.querySelector('#chartCanvas').toDataURL()")
results['symbol_changes_chart']=after_symbol!=initial
results['timeframe_switch']=ev("(()=>{const e=document.querySelector('#timeframeSelect');e.value='1h';e.dispatchEvent(new Event('change',{bubbles:true}));return e.value==='1h'})()")
active_before=ev("document.querySelector('.layer-tab').classList.contains('active')")
active_after=ev("(()=>{document.querySelector('.layer-tab').click();return document.querySelector('.layer-tab').classList.contains('active')})()")
results['layer_toggle']=active_before and not active_after
old_dir=ev('document.documentElement.dir');new_dir=ev("(()=>{document.querySelector('#langBtn').click();return document.documentElement.dir})()")
results['rtl_ltr_toggle']=old_dir!=new_dir
results['workspace_save']=ev("(()=>{document.querySelector('#saveBtn').click();return !!window.__stratixStorage.getItem('stratix.workspace')})()")
results['css_rules_loaded']=ev('[...document.styleSheets].reduce((n,s)=>n+(s.cssRules?.length||0),0) > 20')
results['runtime_errors']=ev('window.__errors')
failed=[key for key,value in results.items() if key!='runtime_errors' and value is not True]
if results['runtime_errors']:failed.append('runtime_errors')
print(json.dumps(results,indent=2,ensure_ascii=False))
ws.close();base_call('Target.closeTarget',{'targetId':target});base.close()
if failed:raise SystemExit('FAILED: '+', '.join(failed))
print('Browser smoke tests passed')

import fs from 'node:fs';
const required=['index.html','style.css','app.js','sw.js','manifest.webmanifest','README.md','CHANGELOG.md'];
for(const f of required){if(!fs.existsSync(new URL('../'+f,import.meta.url)))throw new Error('Missing '+f)}
const html=fs.readFileSync(new URL('../index.html',import.meta.url),'utf8');
for(const s of ['STRATIX','DEMO DATA','TOP 7 ORDERS','LIQUIDITY & ORDER FLOW','DECISION EDGE','MTF MATRIX'])if(!html.includes(s))throw new Error('Missing marker '+s);
const manifest=JSON.parse(fs.readFileSync(new URL('../manifest.webmanifest',import.meta.url),'utf8'));
if(manifest.display!=='standalone')throw new Error('PWA display must be standalone');
console.log('Smoke tests passed:',required.length,'files, manifest valid, UI markers present');
